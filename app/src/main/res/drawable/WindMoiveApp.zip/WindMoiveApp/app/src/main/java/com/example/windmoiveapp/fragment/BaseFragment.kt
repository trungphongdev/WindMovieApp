package com.example.windmoiveapp.fragment

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Context.CONNECTIVITY_SERVICE
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Build
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.navOptions
import com.example.windmoiveapp.MainActivity
import com.example.windmoiveapp.R

class BaseFragment : Fragment() {

    fun NavController.navigateWithAnim(
        idDestination: Int,
        bundle: Bundle? = null,
        popupToId: Int? = null
    ) {
        val anim = navOptions {
            anim {
                popEnter = androidx.navigation.ui.R.anim.nav_default_pop_enter_anim
                popExit = androidx.navigation.ui.R.anim.nav_default_pop_exit_anim
                enter = androidx.navigation.ui.R.anim.nav_default_enter_anim
                exit = androidx.navigation.ui.R.anim.nav_default_enter_anim
            }
            popupToId?.let {
                popUpTo(popupToId) {
                    inclusive = true
                }
            }
        }
        this.navigate(idDestination, bundle, anim)
    }

    fun NavController.navigateBottomWithAnim(
        idDestination: Int,
        bundle: Bundle? = null,
        popupToId: Int? = null
    ) {
        val anim = navOptions {
            anim {
                popEnter = androidx.navigation.ui.R.anim.nav_default_pop_enter_anim
                popExit = androidx.navigation.ui.R.anim.nav_default_pop_exit_anim
                enter = androidx.navigation.ui.R.anim.nav_default_enter_anim
                exit = androidx.navigation.ui.R.anim.nav_default_enter_anim
            }
            popupToId?.let {
                popUpTo(popupToId) {
                    inclusive = true
                }
            }
        }
        this.navigate(idDestination, bundle, anim)
    }

    fun NavController.navigateBackWithAnim(
        idDestination: Int,
        bundle: Bundle? = null,
        popupToId: Int? = null
    ) {
        val anim = navOptions {
            anim {
                popEnter = androidx.navigation.ui.R.anim.nav_default_pop_enter_anim
                popExit = androidx.navigation.ui.R.anim.nav_default_pop_exit_anim
                enter = androidx.navigation.ui.R.anim.nav_default_enter_anim
                exit = androidx.navigation.ui.R.anim.nav_default_enter_anim
            }
            popupToId?.let {
                popUpTo(popupToId) {
                    inclusive = true
                }
            }
        }
        this.navigate(idDestination, bundle, anim)
    }


    fun Activity.restartApp() {
       // (this as? MainActivity)?.resetSession()
        val newIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        this.startActivity(newIntent)
        finish()
    }

    @SuppressLint("MissingPermission")
    fun Context.isNetWorkAvailable(): Boolean {
        val connMgr = this.getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        connMgr.allNetworks.forEach { network ->
            if (connMgr.getNetworkInfo(network)?.isConnected == true) {
                return true
            }
        }
        return false
    }
}
package com.example.windmoiveapp.util

const val BASE_URL = ""
const val TIME_OUT = 30000L

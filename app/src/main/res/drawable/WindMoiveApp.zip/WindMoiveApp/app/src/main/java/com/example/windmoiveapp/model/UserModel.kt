package com.example.windmoiveapp.model

data class UserModel(
    val uid: String,
    val name: String?) {
}
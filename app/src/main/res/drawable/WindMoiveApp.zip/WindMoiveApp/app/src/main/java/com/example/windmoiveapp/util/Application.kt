package com.example.windmoiveapp.util

object Application {

}